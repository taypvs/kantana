<?php
class Muserhome extends CI_Model{
    protected $_table = 'career';
    public function __construct(){
        parent::__construct();
    }

    

}
?>
